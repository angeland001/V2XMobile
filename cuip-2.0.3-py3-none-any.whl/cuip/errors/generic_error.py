import sys
from cuip.logger.logger import bcolors


def _handle_generic_error():
    print(bcolors.ERROR + "Something went wrong.")
    sys.exit()
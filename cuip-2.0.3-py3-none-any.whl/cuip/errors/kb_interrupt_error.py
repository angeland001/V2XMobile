import sys
from cuip.logger.logger import bcolors


def _handle_keyboard_interrupt() -> None:
    print(bcolors.WARNING +
          f"Terminated connection with CUIP resources." + bcolors.WARNING)
    sys.exit()

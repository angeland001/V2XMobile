import sys
from cuip.logger.logger import bcolors


def _handle_unauthorized() -> None:
    print(bcolors.ERROR +
          f"Unauthorized." + bcolors.ERROR)
    sys.exit()

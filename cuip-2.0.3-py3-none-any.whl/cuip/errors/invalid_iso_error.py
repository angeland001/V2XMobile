import sys
from cuip.logger.logger import bcolors


def _handle_iso_format_error():
    print(f'{bcolors.ERROR} Invalid ISO date.')
    sys.exit()


if __name__ == "__main__":
    print(_handle_iso_format_error())

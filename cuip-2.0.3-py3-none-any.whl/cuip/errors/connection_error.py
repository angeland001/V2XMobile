import sys
from cuip.logger.logger import bcolors


def _handle_connection_error():
    print(bcolors.ERROR + "Error connecting to CUIP Resources." + bcolors.ENDC)
    sys.exit()
MLK_INTERSECTIONS = ['MLK_Pine', 'MLK_Chestnut', 'MLK_Broad', 'MLK_Market', 'MLK_Georgia',
                     'MLK_Lindsay', 'MLK_Houston', 'MLK_Douglas', 'MLK_Peeples', 'MLK_Magnolia', 'MLK_Central']

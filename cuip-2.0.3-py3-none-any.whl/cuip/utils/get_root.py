from pathlib import Path


def get_root() -> Path:
    """
    Finds the root of a project directory at any level.

    Returns:
        Path: Project Root
    """
    return Path(__file__).parent.parent

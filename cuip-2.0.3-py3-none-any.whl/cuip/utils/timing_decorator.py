from functools import wraps
from time import time


def timing(f):
    """
    A timing decorator function.

    Args:
        f (func): A function to wrap.

    Returns:
        f (Any) -> The return result of the function and a sys.out result message.
    """
    @wraps(f)
    def wrap(*args, **kw):
        ts = time()
        result = f(*args, **kw)
        te = time()
        print('func:%r args:[%r, %r] took: %2.4f sec' %
              (f.__name__, args, kw, te-ts))
        return result
    return wrap

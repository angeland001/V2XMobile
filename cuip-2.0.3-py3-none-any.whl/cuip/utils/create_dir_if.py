import os

from cuip.logger.logger import bcolors

def _create_dir_if(path: str) -> None:
    """
    If the directory does not exist, create it.

    If the user does not have file-system write permissions, warn them.

    Args:
        root (str): The root path.
        path (str): The output directory path to write the data contents to.
    """
    p = f'{path}'
    isExist = os.path.exists(p)
    if not isExist:
        try:
            os.makedirs(p)
        except OSError:
            print(bcolors.ERROR + f"Issue writing to path: {path}." + bcolors.ENDC)

if __name__ == "__main__":
    _create_dir_if('data')
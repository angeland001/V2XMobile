import datetime
import sys


def validate_day(year: int, month: int, day: int) -> None:
    """
    Takes a year, month, and int and attempts to construct a valid date.

    Args:
        year (int): the year
        month (int): the month
        day (int): the day

    Returns:
        Either allows the date to be constructed or prints messages and exits.
    """
    try:
        datetime.date(year, month, day)
        return None
    except ValueError:
        print('Invalid day. Did you make a type o?')
        sys.exit()

import sys

available_years_set = set([2021, 2020, 2019])


def validate_available_years(year: int) -> None:
    """
    Validates the given year using set membership, if the year is available in the set
    then simply return, otherwise hint and terminate.

    Args:
        year (int): The year to be validated

    Raises:
        SystemExit: Terminate the execution of the program if the value is not a member of the value set.

    Returns:
        bool: true if the value is a member of the set.
    """
    if year in available_years_set:
        return None
    else:
        print('Data is not available for that year.')
        sys.exit()
        
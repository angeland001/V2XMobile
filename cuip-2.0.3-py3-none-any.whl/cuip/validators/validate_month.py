import sys


def validate_month(month: int) -> None:
    """
    Validates the user provided month.

    Args:
        month (int): Make sure to cast the str input to int.

    Raises:
        SystemExit: Terminate the execution of the program if the value is not a member of the value set.

    Returns:
        None: true if the value is a member of the set.
    """
    if month > 0 and month <= 12:
        return None
    else:
        print('Invalid month. Did you make a type o?')
        sys.exit()

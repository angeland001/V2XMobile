from cuip.errors.invalid_iso_error import _handle_iso_format_error


def _validate_iso_date(date_string: str) -> bool:
    # if len(date_string) != 19 or len(date_string) != 26:
    #     _handle_iso_format_error()
    return True

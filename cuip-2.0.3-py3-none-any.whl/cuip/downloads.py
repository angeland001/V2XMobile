# from cuip.constants import MLK_INTERSECTIONS
from cuip.errors.generic_error import _handle_generic_error
from cuip.lib.download import _download_count_data

from cuip.intersections import MLK_INTERSECTIONS


class Downloads():
    """
    Download historic CUIP data.
    """

    def __init__(self, api_key):
        self.api_key = api_key

    def download_single_count_data(self, date: str, intersection: str, output_dir: str) -> None:
        """
        Download Gridsmart count data as a zip folder for an intersection by date.

        Args:
            date (str): The target date in YYYY-MM-DD format.
            intersection (str): the name of the target intersection
            output_dir (str): The download output directory relative to your project root directory.
        """
        try:
            
            # TODO validate intersection via input

            _download_count_data(self.api_key, date, intersection, output_dir)
        except Exception:
            _handle_generic_error()

    def download_all_count_data_for_date(self, date: str, output_dir: str):
        """
        Download all count data as a zip folder for each intersection by date.

        Args:
            date (str): The target date in YYYY-MM-DD format.
            output_dir (str): The download output directory relative to your project root directory.
        """

        try:
            for intersection in MLK_INTERSECTIONS:
                _download_count_data(self.api_key, date, intersection,
                                     f'{output_dir}/{date}/{intersection}-{date}')
        except Exception:
            _handle_generic_error()
            
# import requests
# import websockets
# from json import loads
# from typing import Callable
# import sys

# from cuip.errors.connection_error import _handle_connection_error
# from cuip.errors.kb_interrupt_error import _handle_keyboard_interrupt
# from cuip.errors.unauthorized_error import _handle_unauthorized
# from cuip.lib.connect_stream import _connect
# from cuip.logger.logger import bcolors


# API_PREFIX = 'http://data.services.utccuip.com/auth'
# BASE_WS_URL = 'ws://cuip-api.research.utc.edu'


# class Streams():
#     """
#     Connect to a real-time CUIP data stream.
#     """

#     def __init__(self, api_key):
#         self.api_key = api_key

#     def process_stream(self, cb, stream_id: str):
#         """
#         Process SPaT messages from the MLK Smart Corridor via websocket.
#         Available Streams: MLK SPaT Events.

#          Requires:
#             VPN connection to CUIP resources.

#          Args:
#             cb (callback): Process a data stream per message.
#             stream_id (str): [The stream identifier string]
#          """
#         try:

#             r = requests.get(API_PREFIX, allow_redirects=True, headers={
#                 "Authorization": self.api_key})

#             if(r and r.status_code == 403):
#                 _handle_unauthorized()

#             if(r and r.status_code == 200):
#                 stream = _connect(stream_id)
#                 for event in stream:
#                     cb(event.value)

#                     if(r and r.status_code == 403):
#                         _handle_unauthorized()
#         except KeyboardInterrupt:
#             _handle_keyboard_interrupt()

#     # ENDPOINT = "ws://10.199.96.67:8765"

#     async def process_ws_stream(self, cb: Callable, stream_id: str):
#         """
#         Process JSON messages from the MLK Smart Corridor via websocket.

#         ```python
#         # Define your callback
#         def process(data):
#             print(data)

#         # available streams
#         GS_REALTIME_ZONE = "gs-realtime-zone"
#         SPAT = "spat-events"

#         asyncio.run(Streams("<api_key>").process_ws_stream(process, SPAT))
#         ```

#         Args:
#             cb (function): Callback function to process a each message of the stream.
#             stream_id (str): "spat-events" or "gs-realtime-zone".
#         """

#         if stream_id == "spat-events":
#             PORT = '8080'

#         elif stream_id == "gs-realtime-zone":
#             PORT = f'8082'

#         elif stream_id == "georgia-lidar-events":
#             PORT = f'8085'

#         elif stream_id == "bsm-events":
#             PORT = f'8086'

#         elif stream_id == "srm-events":
#             PORT = f'8087'

#         elif stream_id == "ssm-events":
#             PORT = f'8088'

#         elif stream_id == "all-lidars-events":
#             PORT = f'8089'

#         elif stream_id == "sdsm-events":
#             PORT = f'8090'

#         else:
#             print("Invalid stream_id, use one of the valid streams.")


#         async with websockets.connect(f"{BASE_WS_URL}:{PORT}") as websocket:
#             async for message in websocket:
#                 try:
#                     cb(loads(message))
#                 except Exception as e:
#                     print(e)

import asyncio
import requests
import websockets
from json import loads
from typing import Callable

from cuip.errors.connection_error import _handle_connection_error
from cuip.errors.kb_interrupt_error import _handle_keyboard_interrupt
from cuip.errors.unauthorized_error import _handle_unauthorized
from cuip.logger.logger import bcolors

API_PREFIX = 'http://data.services.utccuip.com/auth'
BASE_WS_URL = 'ws://cuip-api.research.utc.edu'


class Streams:
    """
    Connect to a real-time CUIP data stream.
    """

    def __init__(self, api_key: str):
        self.api_key = api_key

    async def process_ws_stream(self, cb: Callable, stream_id: str):
        """
        Process JSON messages from the MLK Smart Corridor via websocket.

        Args:
            cb (Callable): Function to handle each received message.
            stream_id (str): One of the valid stream identifiers.
        """

        # ------------------------
        # 1. Resolve Stream Port
        # ------------------------
        ports = {
            "spat-events": 8080,
            "gs-realtime-zone": 8082,
            "georgia-lidar-events": 8085,
            "bsm-events": 8086,
            "srm-events": 8087,
            "ssm-events": 8088,
            "all-lidars-events": 8089,
            "sdsm-events": 8090,
        }

        if stream_id not in ports:
            print(f"{bcolors.ERROR}[Error]{bcolors.ENDC} Invalid stream_id: '{stream_id}'")
            print("Valid streams:", ", ".join(ports.keys()))
            return

        port = ports[stream_id]
        url = f"{BASE_WS_URL}:{port}"


        # ------------------------
        # 3. WebSocket Connection
        # ------------------------
        print(f"{bcolors.OKBLUE}[Connecting]{bcolors.ENDC} → {url}")
        try:
            async with websockets.connect(url) as websocket:
                print(f"{bcolors.OKGREEN}[Connected]{bcolors.ENDC} Listening to '{stream_id}'")

                # Streams like GridSmart send data every ~1–2 minutes
                warning_interval = 180  # seconds before idle warning
                while True:
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=warning_interval)
                        cb(loads(message))

                    except asyncio.TimeoutError:
                        print(
                            f"{bcolors.WARNING}[Notice]{bcolors.ENDC} "
                            f"No messages received in the last {warning_interval // 60} minute(s) for '{stream_id}'. "
                            f"The stream may be idle but still connected."
                        )
                        continue

                    except websockets.exceptions.ConnectionClosedError as e:
                        print(f"{bcolors.WARNING}[Warning]{bcolors.ENDC} Connection closed: {e}")
                        return _handle_connection_error()

                    except Exception as e:
                        print(f"{bcolors.ERROR}[Error]{bcolors.ENDC} Message processing failed: {e}")
                        continue

        except (OSError, websockets.exceptions.InvalidStatusCode) as e:
            print(f"{bcolors.ERROR}[Error]{bcolors.ENDC} Could not connect to {url}: {e}")
            return _handle_connection_error()

        except KeyboardInterrupt:
            _handle_keyboard_interrupt()

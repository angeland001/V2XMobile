import sys
import requests
from cuip.errors.connection_error import _handle_connection_error
from cuip.errors.generic_error import _handle_generic_error
from cuip.logger.logger import bcolors

from cuip.utils.create_dir_if import _create_dir_if
from cuip.helpers.format_req_date import _format_req_date


def _download_count_data(api_key: str, date: str, intersection: str, output_dir: str):
    """
    Download historic GridSmart count data from object storage.

    Args:
        api_key(str): API-Key for auth
        date (str): The date in YYYY-MM-DD
        intersection (str): MLK Smart Corridor intersection.
        destination (str): Download destination path.
    """
    if(isinstance(date, str) == str or len(date) != 10):
        print(f'{bcolors.ERROR} Incorrect date format - please use YYYY-MM-DD.')
        sys.exit()

    if output_dir[0] == "/":
        print(
            f'{bcolors.ERROR} Do not use leading / for download path.')
        sys.exit()

    f_date = _format_req_date(date)

    API_PREFIX = "http://cuip-api.research.utc.edu:8081/data"
    # API_PREFIX = "http://localhost:8081/data"

    url = f'{API_PREFIX}/{f_date}/{intersection}'

    try:
        r = requests.get(url, allow_redirects=True, headers={
                         "Authorization": api_key})

    except OSError:
        _handle_connection_error()

    except Exception:
        _handle_generic_error()

    _create_dir_if(output_dir)

    if r.content and r.status_code == 200:
        with open(f'/home/yasir/{date}.zip', 'wb') as output_file:
            output_file.write(r.content)
    elif r.status_code == 204:
        print(
            f'{bcolors.WARNING} Data is not available for {intersection} at {date}. {bcolors.WARNING} ')
    else:
        _handle_generic_error()

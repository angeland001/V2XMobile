import sys
from json import loads
from kafka import KafkaConsumer


def _connect(stream: str):
    '''
    Connects to CUIP live-stream data.
    '''
    try:
        consumer = KafkaConsumer(
            stream,
            bootstrap_servers=['cuip-kafka1.research.utc.edu:9092',
                               'cuip-kafka2.research.utc.edu:9092', 'cuip-kafka3.research.utc.edu:9092'],
            auto_offset_reset='latest',
            enable_auto_commit=False,
            # TODO Change this group id.
            group_id='cuip_package',
            value_deserializer=lambda x: loads(x.decode('utf-8')))
        return consumer

    except Exception as e:
        error = type(e).__name__
        if(error == "NoBrokersAvailable"):
            print('ERROR CONNECTING TO CUIP RESOURCES')
            sys.exit()
        else:
            print(
                'An unknown error has occurred. Please try again later.')
            sys.exit()

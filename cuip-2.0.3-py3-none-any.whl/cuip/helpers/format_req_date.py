from cuip.validators.validate_day import validate_day
from cuip.validators.validate_month import validate_month
from cuip.validators.validate_year import validate_available_years


def _format_req_date(date: str) -> str:
    """
    Validates date input and transforms it into object storage request format.

    Args:
        date (str): The given date str via input.

    Returns:
        str: Date string compatible for object storage retrieval.
    """

    parsed_date = date.split('-')

    year = parsed_date[0]
    iyear = int(year)
    validate_available_years(iyear)

    month = parsed_date[1]
    imonth = int(month)
    validate_month(imonth)

    day = parsed_date[2]
    iday = int(day)
    validate_day(iyear, imonth, iday)

    formatted_date = "/".join(parsed_date)

    return formatted_date


if __name__ == "__main__":
    date = input('Enter a date to validate \n')
    _format_req_date(date)
from datetime import datetime


def _format_iso_date(date_string: str) -> str:
    """
    Formats ISO date into req query format.

    Args:
        date_string (str): An ISO date string (YYYY-MM-DD HH:MM:SS.000000).

    Returns:
        str: YYYY-MM-DD%HH:MM:SS.000000
    """
    date_string = date_string.replace(' ', 'T')
    return date_string[:22]
    


if __name__ == "__main__":
    now = datetime.now()
    print("before: ", str(now))
    result = _format_iso_date(str(now))
    print("after: ", result)